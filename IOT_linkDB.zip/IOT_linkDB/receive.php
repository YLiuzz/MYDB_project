<?php 

//info ==user, database

$data = $_GET['value' ];
$data2 = $_GET['pp' ]; //傳第二個值

$servername = "localhost";
$username = "test123";
$password = "test123";
//database information
$databaseName = "iot";
$tableName = "light";
//connect dbms

$con=mysqli_connect($servername, $username, $password,$databaseName);

if ($con->connect_error) {
    die("Too bad!!!! Connection failed: " . $con->connect_error);
} 
//echo "Connected successfully !!!! Yayaya.....";

//connect db
// Change database to "test"
mysqli_select_db($con,$tableName);

//select
//Query database for data
 
$result = mysqli_query($con,"insert into $tableName (value) VALUE ($data)");
$result = mysqli_query($con,"insert into $tableName (value) VALUE ($data2)");

  //store matrix
  
if ($result==1) {
	echo "successfully";
} else {
	echo "error";
}


  //echo result as json 
    

//close db
mysqli_close($con);

 ?>


